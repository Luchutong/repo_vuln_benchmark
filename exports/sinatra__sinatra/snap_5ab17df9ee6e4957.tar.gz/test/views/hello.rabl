object @foo
attributes :bar
