export class ExternalSvc {}
