macro_rules! ready {
    ($e:expr) => {
        match $e {
            std::task::Poll::Ready(v) => v,
            std::task::Poll::Pending => return std::task::Poll::Pending,
        }
    };
}

pub(crate) mod buf;
#[cfg(any(feature = "http1", feature = "http2"))]
#[cfg(feature = "server")]
pub(crate) mod date;
#[cfg(any(feature = "http1", feature = "http2"))]
#[cfg(feature = "server")]
pub(crate) mod drain;
#[cfg(any(feature = "http1", feature = "http2"))]
pub(crate) mod exec;
pub(crate) mod io;
#[cfg(any(feature = "http1", feature = "http2"))]
#[cfg(feature = "client")]
mod lazy;
mod never;
#[cfg(feature = "stream")]
pub(crate) mod sync_wrapper;
pub(crate) mod task;
pub(crate) mod watch;

#[cfg(any(feature = "http1", feature = "http2"))]
#[cfg(feature = "client")]
pub(crate) use self::lazy::{lazy, Started as Lazy};
pub use self::never::Never;
pub(crate) use self::task::Poll;

// group up types normally needed for `Future`
cfg_proto! {
    pub(crate) use std::marker::Unpin;
}
pub(crate) use std::{future::Future, pin::Pin};
